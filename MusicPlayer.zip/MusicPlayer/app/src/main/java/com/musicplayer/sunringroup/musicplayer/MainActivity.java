package com.musicplayer.sunringroup.musicplayer;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;

import com.neurosky.AlgoSdk.NskAlgoConfig;
import com.neurosky.AlgoSdk.NskAlgoDataType;
import com.neurosky.AlgoSdk.NskAlgoSdk;
import com.neurosky.AlgoSdk.NskAlgoSignalQuality;
import com.neurosky.AlgoSdk.NskAlgoState;
import com.neurosky.AlgoSdk.NskAlgoType;
import com.neurosky.connection.ConnectionStates;
import com.neurosky.connection.TgStreamHandler;
import com.neurosky.connection.TgStreamReader;
import com.neurosky.connection.DataType.MindDataType;

import com.androidplot.xy.*;


public class MainActivity extends AppCompatActivity {
    final String TAG = "MainActivityTag";
    boolean NO_Bluetooth = true;

    ArrayList<Songs> songs = new ArrayList<>();
    private Button start, stop;
    private TextView medtext, status;
    private ImageView medImg;

    private BluetoothAdapter mBluetoothAdapter;
    private TgStreamReader tgStreamReader;

    private NskAlgoSdk nskAlgoSdk;
    private boolean bRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nskAlgoSdk = new NskAlgoSdk();

        try {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
                Toast.makeText(this,
                        "Please Make sure enable Bluetooth",
                        Toast.LENGTH_LONG).show();

                NO_Bluetooth = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.i(TAG, "error : " + e.getMessage());
            return;
        }

        start = (Button)this.findViewById(R.id.start);
        stop = (Button)this.findViewById(R.id.stop);

        medtext = (TextView)this.findViewById(R.id.medtext);
        status = (TextView) this.findViewById(R.id.status);
        medImg = (ImageView)this.findViewById(R.id.MedImg);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               start.setEnabled(false);
               stop.setEnabled(false);

                tgStreamReader = new TgStreamReader(mBluetoothAdapter,callback);

                if(tgStreamReader != null && tgStreamReader.isBTConnected()){

                    // Prepare for connecting
                    tgStreamReader.stop();
                    tgStreamReader.close();
                }
                try {
                    tgStreamReader.connect();
                    Toast.makeText(getApplicationContext(),
                            "EEG Connected",
                            Toast.LENGTH_SHORT).show();

                    stop.setEnabled(true);

                } catch (Exception e) {
                    if(NO_Bluetooth == false) {
                        Toast.makeText(getApplicationContext(),
                                "No Bluetooth",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(),
                                "EEG not Connected",
                                Toast.LENGTH_SHORT).show();
                    }
                    start.setEnabled(true);
                    stop.setEnabled(true);
                    e.printStackTrace();
                    Log.i(TAG, "Error : " + e.getMessage());
                    return;
                }

                if(bRunning == false) {
                    nskAlgoSdk.NskAlgoStart(false);
                } else {
                    Toast.makeText(getApplicationContext(), "EEG already Connected", Toast.LENGTH_SHORT).show();
                }

                nskAlgoSdk.setOnSignalQualityListener(new NskAlgoSdk.OnSignalQualityListener() {
                    @Override
                    public void onSignalQuality(final int level) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // change UI elements here
                                String sqStr = NskAlgoSignalQuality.values()[level].toString();
                                Toast.makeText(getApplicationContext(),
                                        "Get quality",
                                        Toast.LENGTH_SHORT).show();
                                status.setText(sqStr);
                            }
                        });
                    }
                });

                nskAlgoSdk.setOnMedAlgoIndexListener(new NskAlgoSdk.OnMedAlgoIndexListener() {
                    @Override
                    public void onMedAlgoIndex(final int medVal) {
                        String medStr = "[" + medVal +"]";
                        final String findMedVal = medStr;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                medtext.setText(findMedVal);
                                if(medVal <= 50) {
                                    medImg.setImageResource(R.drawable.heart_before_50);
                                } else {
                                    medImg.setImageResource(R.drawable.heart_50);
                                }
                            }
                        });
                    }
                });
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start.setEnabled(true);
                nskAlgoSdk.NskAlgoStop();
            }
        });

        ListView listView = findViewById(R.id.MusicPlayerList);
        CustomAdapter adapter = new CustomAdapter(songs);
        listView.setAdapter(adapter);

        songs.add(new Songs("https://is1-ssl.mzstatic.com/image/thumb/Music128/v4/2a/c3/c5/2ac3c526-6377-4746-1e16-d2c6df0e07b4/17UM1IM10153.jpg/1200x630bb.jpg", "Despacito", "LuisFonsi", 1));
        songs.add(new Songs("https://i1.sndcdn.com/artworks-000222916265-ikc87l-t500x500.jpg", "Galway_Girl", "EdSheeran", 2));
        songs.add(new Songs("https://i.scdn.co/image/95288d304e7c7c35fc112a8380d883f963b63d6d", "Revolution", "The_Score", 3));
        songs.add(new Songs("http://salacioussound.com/wp-content/uploads/2015/11/AlbumCover-390x390.jpg", "Sugar", "Maroon5", 4));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, MusicPlayer.class);

                intent.putExtra("ImgRes", songs.get(position).getImgRes());
                intent.putExtra("title", songs.get(position).getTitle());
                intent.putExtra("subtitle", songs.get(position).getSubtitle());
                intent.putExtra("SongID", songs.get(position).getSongID());

                startActivity(intent);
                System.exit(0);
            }
        });

    }
    private TgStreamHandler callback = new TgStreamHandler() {
        @Override
        public void onDataReceived(int datatype, int data, Object obj) {
            switch (datatype) {
                case MindDataType.CODE_MEDITATION :
                    short medValue[] = {(short)data};
                    nskAlgoSdk.NskAlgoDataStream(NskAlgoDataType.NSK_ALGO_DATA_TYPE_MED.value, medValue, 1);
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onStatesChanged(int connectionStates) {
            switch (connectionStates) {
                case ConnectionStates.STATE_CONNECTED :
                    Toast.makeText(getApplicationContext(),
                            "EEG Connected",
                            Toast.LENGTH_SHORT).show();
                    break;
                case ConnectionStates.STATE_WORKING :
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(!mBluetoothAdapter.isEnabled()) {
                                Toast.makeText(getApplicationContext(), "NO Bluetooth", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
            }
        }

        @Override
        public void onChecksumFail(byte[] bytes, int i, int i1) {

        }

        @Override
        public void onRecordFail(int i) {

        }
    };
}
