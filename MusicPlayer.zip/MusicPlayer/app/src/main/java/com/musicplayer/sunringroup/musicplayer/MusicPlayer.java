package com.musicplayer.sunringroup.musicplayer;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.jackandphantom.blurimage.BlurImage;
import com.neurosky.AlgoSdk.NskAlgoSdk;
import com.neurosky.AlgoSdk.NskAlgoSignalQuality;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MusicPlayer extends AppCompatActivity {
    int PauseChanger = -1;
    private Handler handler = new Handler();

    private ImageView MusicMedImg, MusicAttImg;
    private TextView MusicMedVal, MusicAttVal;

    MediaPlayer mediaPlayer = new MediaPlayer();
    ArrayList<Songs> songs = new ArrayList<>();

    private NskAlgoSdk nskAlgoSdk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_player);

        MusicMedImg = (ImageView)this.findViewById(R.id.MusicMedImg);
        MusicAttImg = (ImageView)this.findViewById(R.id.MusicAttImg);
        MusicMedVal = (TextView) this.findViewById(R.id.MusicMedVal);
        MusicAttVal = (TextView)this.findViewById(R.id.MusicAttVal);

        final SeekBar seekbar = (SeekBar) findViewById(R.id.SeekBar);

        Button MusicPlayerBack = (Button) findViewById(R.id.MusicPlayerBack);
        final Button MusicPlayerPlayPause = (Button) findViewById(R.id.MusicPlayerPlayPause);
        Button MusicPlayerNext = (Button) findViewById(R.id.MusicPlayerNext);

        Intent getIntent = getIntent();
        final Intent sendIntent = new Intent(this, MusicPlayer.class);

        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        final ImageView MusicPlayerBackGround = (ImageView) findViewById(R.id.MusicPlayerBackGround);
        TextView  MusicPlayerTitle = (TextView) findViewById(R.id.MusicPlayerTitle);
        TextView MusicPlayerSubTitle = (TextView) findViewById(R.id.MusicPlayerSubtitle);

        final int SongID = getIntent.getIntExtra("SongID",1);

        switch (SongID) {
            case 1:
                mediaPlayer.release();

                MusicPlayerTitle.setText("Desepacito");
                MusicPlayerSubTitle.setText("LuisFonsi");

                mediaPlayer = MediaPlayer.create(this, R.raw.despacito);
                seekbar.setMax(mediaPlayer.getDuration());

                Picasso.get()
                        .load("https://is1-ssl.mzstatic.com/image/thumb/Music128/v4/2a/c3/c5/2ac3c526-6377-4746-1e16-d2c6df0e07b4/17UM1IM10153.jpg/1200x630bb.jpg")
                        .transform(new BlurTransformation(this, 25))
                        .into(MusicPlayerBackGround);

                Picasso.get()
                        .load("https://is1-ssl.mzstatic.com/image/thumb/Music128/v4/2a/c3/c5/2ac3c526-6377-4746-1e16-d2c6df0e07b4/17UM1IM10153.jpg/1200x630bb.jpg")
                        .into(imageView);

                break;

            case 2:
                mediaPlayer.release();

                MusicPlayerTitle.setText("Galway_Girl");
                MusicPlayerSubTitle.setText("EdSheeran");

                mediaPlayer = MediaPlayer.create(this, R.raw.galway_girl);
                seekbar.setMax(mediaPlayer.getDuration());

                Picasso.get()
                        .load("https://i1.sndcdn.com/artworks-000222916265-ikc87l-t500x500.jpg")
                        .transform(new BlurTransformation(this, 25))
                        .into(MusicPlayerBackGround);

                Picasso.get()
                        .load("https://i1.sndcdn.com/artworks-000222916265-ikc87l-t500x500.jpg")
                        .into(imageView);

                break;

            case 3:
                mediaPlayer.release();

                mediaPlayer = MediaPlayer.create(this, R.raw.revolution);
                seekbar.setMax(mediaPlayer.getDuration());

                MusicPlayerTitle.setText("Revolution");
                MusicPlayerSubTitle.setText("The_Score");

                Picasso.get()
                        .load("https://i.scdn.co/image/95288d304e7c7c35fc112a8380d883f963b63d6d")
                        .transform(new BlurTransformation(this, 25))
                        .into(MusicPlayerBackGround);

                Picasso.get()
                        .load("https://i.scdn.co/image/95288d304e7c7c35fc112a8380d883f963b63d6d")
                        .into(imageView);

                break;

            case 4:
                mediaPlayer.release();

                MusicPlayerTitle.setText("Sugar");
                MusicPlayerSubTitle.setText("Maroon5");

                mediaPlayer = MediaPlayer.create(this, R.raw.sugar);
                seekbar.setMax(mediaPlayer.getDuration());

                Picasso.get()
                        .load("http://salacioussound.com/wp-content/uploads/2015/11/AlbumCover-390x390.jpg")
                        .transform(new BlurTransformation(this, 25))
                        .into(MusicPlayerBackGround);

                Picasso.get()
                        .load("http://salacioussound.com/wp-content/uploads/2015/11/AlbumCover-390x390.jpg")
                        .into(imageView);

                break;
        }

        MusicPlayer.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mediaPlayer != null) {
                    int CurrentPostion = mediaPlayer.getCurrentPosition();
                    seekbar.setProgress(CurrentPostion);

                    try {
                        nskAlgoSdk.setOnAttAlgoIndexListener(new NskAlgoSdk.OnAttAlgoIndexListener() {
                            @Override
                            public void onAttAlgoIndex(final int attVal) {
                                String attStr = "[" + attVal + "]";
                                final String findAttVal = attStr;
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        MusicAttVal.setText(findAttVal);
                                        if(attVal <= 50) {
                                            MusicAttImg.setImageResource(R.drawable.concent_before_50);
                                        } else {
                                            MusicAttImg.setImageResource(R.drawable.concent_50);
                                        }
                                    }
                                });
                            }
                        });

                        nskAlgoSdk.setOnMedAlgoIndexListener(new NskAlgoSdk.OnMedAlgoIndexListener() {
                            @Override
                            public void onMedAlgoIndex(final int medVal) {
                                String medStr = "[" + medVal +"]";
                                final String findMedVal = medStr;
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        MusicMedVal.setText(findMedVal);
                                        if(medVal <= 50) {
                                            MusicMedImg.setImageResource(R.drawable.heart_before_50);
                                        } else {
                                            MusicMedImg.setImageResource(R.drawable.heart_50);
                                        }
                                    }
                                });
                            }
                        });

                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "No Connection", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
                handler.postDelayed(this, 1000);
            }
        });

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(mediaPlayer != null && fromUser) {
                    mediaPlayer.pause();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mediaPlayer.pause();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(seekBar.getProgress());
                mediaPlayer.start();
            }
        });

        MusicPlayerBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                if (SongID == 1) {
                    Toast.makeText(getApplicationContext(), "가장 처음 음악 입니다.", Toast.LENGTH_SHORT).show();
                } else {
                    sendIntent.putExtra("SongID", SongID - 1);
                    startActivity(sendIntent);
                    finish();
                }
            }
        });

        MusicPlayerPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(PauseChanger == 1) {
                    mediaPlayer.pause();
                    MusicPlayerPlayPause.setBackgroundResource(R.drawable.ic_play_arrow_black_24dp);
                    PauseChanger = PauseChanger * (-1);

                } else {
                    mediaPlayer.start();
                    MusicPlayerPlayPause.setBackgroundResource(R.drawable.ic_pause_black_24dp);
                    PauseChanger =  PauseChanger * (-1);
                }
            }
        });

        MusicPlayerNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.stop();
                if (SongID == 4) {
                    Toast.makeText(getApplicationContext(), "가장 마지막 음악 입니다.", Toast.LENGTH_SHORT).show();
                } else {
                    sendIntent.putExtra("SongID", SongID + 1);
                    startActivity(sendIntent);
                    finish();
                }
            }
        });
    }
}
