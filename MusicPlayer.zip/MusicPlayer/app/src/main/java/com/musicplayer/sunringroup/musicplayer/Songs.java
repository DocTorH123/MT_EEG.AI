package com.musicplayer.sunringroup.musicplayer;

public class Songs {

    private int SongID;
    private String title, subtitle, imgRes;

    public Songs(String imgRes, String title, String subtitle, int SongID) {
        this.imgRes = imgRes;
        this.title = title;
        this.subtitle = subtitle;
        this.SongID= SongID;
    }

    public String getImgRes() {
        return imgRes;
    }

    public void setImgRes(String imgRes) {
        this.imgRes = imgRes;
    }

    public int getSongID() {
        return SongID;
    }

    public void setSongID(int SongID) {
        this.SongID = SongID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
