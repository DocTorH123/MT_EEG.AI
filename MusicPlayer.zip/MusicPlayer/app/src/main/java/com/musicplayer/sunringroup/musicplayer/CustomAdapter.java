package com.musicplayer.sunringroup.musicplayer;

import android.graphics.Color;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {
    ArrayList<Songs> Songs;

    public CustomAdapter(ArrayList<Songs> Songs) {
        this.Songs = Songs;
    }

    @Override
    public int getCount() {
        return Songs.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item, null);

        ImageView imageView = v.findViewById(R.id.image);
        Picasso.get()
                .load(Songs.get(position).getImgRes())
                .into(imageView);

        TextView title = v.findViewById(R.id.title_text);
        title.setText(Songs.get(position).getTitle());

        TextView subtilte = v.findViewById(R.id.subtilte_text);
        subtilte.setText(Songs.get(position).getSubtitle());

        TextView SongID = v.findViewById(R.id.SongID);
        SongID.setText(Integer.toString(Songs.get(position).getSongID()));

        return v;
    }
}
